package com.menus;
import com.cardtypes.*;
/* Class created by Tanner Brelje
 * Date: 3/21/2017
 */
 
public class MainMenu {

	public void AddCard(){
		
		// TODO: Calls a function to be written later that
		// takes in the information used.
		
		// TODO: Gets the collection type.
		String coltype = null;
		
		// Creates a new card based on the type.
		if (coltype == "Pokemon"){
			PokemonCard card = new PokemonCard();
		}
		else if (coltype == "YuGiOh"){
			YuGiOhCard card = new YuGiOhCard();
		}
		else if (coltype == "Magic"){
			MagicCard card = new MagicCard();
		}
		else{
			// TODO: TradingCard card = new TradingCard();
		}
		
		// TODO: Fill out the information for the card.
		
		// TODO: Add card to database.
	}
	
	public void RemoveCard(){
		
		// TODO: Decrements the amount of card in the database.
		
		// TODO: If 0 cards left, the card is removed.
	}
}
