package com.cardtypes;
/* Class created by Tanner Brelje
 * Date: 3/21/2017
 */

public class YuGiOhCard {
	
	/* A YuGiOh card contains the following defining factors:
	 * card name -> Name of the image on the card.
	 * card set -> The over-arching set the card belongs to.
	 * card setno -> Id of the card. This is the number of the card
	 * 		as it pertains to the set. Ex. Set-setno
	 */
	public String name;
	public String set;
	public String setno;
	
	
	// Getter for the name of the card
	public String getName(){
		return name;
	}
	
	// Getter for the set of the card
	public String getSet(){
		return set;
	}
	
	// Getter for the setno of the card
	public String getSetNumber(){
		return setno;
	}
	
	// Setter for the name of the card
	public void setName(String x){
		name = x;
	}
	
	// Setter for the set of the card
	public void setSet(String x){
		set = x;
	}
	
	// Setter for the setno of the card
	public void setSetNumber(String x){
		setno = x;
	}

}
