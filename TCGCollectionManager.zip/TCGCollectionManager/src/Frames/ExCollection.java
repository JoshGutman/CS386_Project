package Frames;

public class ExCollection {

}
