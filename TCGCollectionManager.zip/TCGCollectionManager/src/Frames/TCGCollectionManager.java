package Frames;

public class TCGCollectionManager{
	
	public static void main(String[] args){
		
		new TCGCollectionManager();
		
	}
	
	public TCGCollectionManager(){
		
		new CollectionSelect();
		
	}
}
